chrome.devtools.panels.create(
  'AISchedule',
  'images/logo.png',
  'devpanels/index.html',
  function (panel) {
    console.log('Devtools Start')
  }
)